#!/bin/bash
# iOS Performance Monitor 启动脚本

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

usage() {
    echo "iOS Performance Monitor"
    echo ""
    echo "用法: $0 <command>"
    echo ""
    echo "命令:"
    echo "  monitor    启动设备连接监控服务"
    echo "  service    启动 WebSocket 性能采集服务"
    echo "  all        启动所有服务（后台运行 monitor）"
    echo "  help       显示帮助信息"
    echo ""
    echo "示例:"
    echo "  $0 monitor           # 启动设备监控"
    echo "  $0 service --port 8766  # 指定端口启动服务"
    echo "  $0 all               # 启动所有服务"
}

case "$1" in
    monitor)
        shift
        exec "$SCRIPT_DIR/ios-perf-monitor" "$@"
        ;;
    service)
        shift
        exec "$SCRIPT_DIR/ios-perf-service" "$@"
        ;;
    all)
        echo "🚀 启动所有服务..."
        echo "  [1] 启动设备监控服务（后台）"
        "$SCRIPT_DIR/ios-perf-monitor" &
        MONITOR_PID=$!
        echo "      PID: $MONITOR_PID"
        
        sleep 2
        
        echo "  [2] 启动 WebSocket 服务（前台）"
        exec "$SCRIPT_DIR/ios-perf-service"
        ;;
    help|--help|-h)
        usage
        ;;
    *)
        usage
        exit 1
        ;;
esac
